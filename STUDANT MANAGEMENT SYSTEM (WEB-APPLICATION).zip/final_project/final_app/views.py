from django.shortcuts import render, redirect
from django.contrib.auth.models import User
from django.contrib.auth import login, logout, authenticate
from.models import DeptModel, StudentModel
from.forms import DeptForm, StudentForm

def sign_in(request):
	if request.method == "POST":
		un = request.POST.get("un")
		pw = request.POST.get("pw")
		ur = authenticate(username = un, password = pw)
		if ur is not None:
			login(request, ur)
			return redirect("dashboard")
		else:
			return render(request, "sign_in.html", {"msg":"INVALID LOGIN"})
	else:
		return render(request, "sign_in.html")

def sign_up(request):
	if request.method == "POST":
		un = request.POST.get("un")
		pw1 = request.POST.get("pw1")
		pw2 = request.POST.get("pw2")
		if pw1 == pw2:
			try:
				ur = User.objects.get(username = un)
				return render(request, "sign_up.html" , {"msg":"USER IS ALREADY EXISTS TRY WITH OTHER NAME"})
			except User.DoesNotExist:
				ur = User.objects.create_user(username = un, password = pw1)
				ur.save()
				return redirect("sign_in")
		else:
			return render(request, "sign_up.html" , {"msg":"PASSWORD DID NOT MATCH"})
	else:
		return render(request, "sign_up.html")

def change_password(request):
	if request.user.is_authenticated:
		if request.method == "POST":
			un = request.POST.get("un")
			pw1 = request.POST.get("pw1")
			pw2 = request.POST.get("pw2")
			if pw1 == pw2:
				try:
					ur = User.objects.get(username = un)
					ur.set_password(pw1)
					ur.save()
					return redirect("sign_in")
				except User.DoesNotExist:
					return render(request, "change_password.html" , {"msg":"USER DOES NOT EXISTS"})
			else:
				return render(request, "change_password.html" , {"msg":"PASSWORD DID NOT MATCH"})	
		else:
			return render(request, "change_password.html")
	else:
		return redirect("sign_in")

def dashboard(request):
	if request.user.is_authenticated:
		return render(request, "dashboard.html")
	else:
		return redirect("sign_in")
		
def ulogout(request):
	logout(request)
	return redirect("sign_in")

def adddept(request):
	if request.method == "POST":
		data = DeptForm(request.POST)
		if data.is_valid():
			data.save()
			msg = "Department Added"
			fm = DeptForm()
			return render(request, "adddept.html", {"fm":fm, "msg":msg})
		else:
			msg = "Check Error"
			return render(request, "adddept.html", {"fm":data, "msg":msg})
	else:
		fm = DeptForm
		return render(request, "adddept.html", {"fm":fm})

def viewdept(request):
	data = DeptModel.objects.all()
	return render(request, "viewdept.html", {"data":data})
		
def viewstudent(request):
	data = StudentModel.objects.all()
	return render(request, "viewstudent.html", {"data":data})

def addstudent(request):
	if request.method == "POST":
		data = StudentForm(request.POST, request.FILES)
		if data.is_valid():
			data.save()
			msg = "Student Added"
			fm = StudentForm()
			return render(request, "addstudent.html", {"fm":fm, "msg":msg})
		else:
			msg = "Check Error"
			return render(request, "addstudent.html", {"fm":data, "msg":msg})
	else:
		fm = StudentForm
		return render(request, "addstudent.html", {"fm":fm})

def removedept(request, id):
	de = DeptModel.objects.get(did = id)
	de.delete()
	return redirect("viewdept")

def removestudent(request, id):
	sm = StudentModel.objects.get(rno = id)
	sm.delete()
	return redirect("viewstudent")

def adminlogin(request):
	if request.method == "POST":
		un = request.POST.get("un")
		pw = request.POST.get("pw")
		if un == "rohanpophale" and pw == "rohan12345":
			return render(request, "adminpage.html")
		else:
			return render(request, "adminlogin.html", {"msg":"INVALID LOGIN"})
	else:
		return render(request, "adminlogin.html")
	
def adminpage(request):
	return render(request, "adminpage.html")

def userlogin(request):
	return render(request, "userlogin.html")












 
