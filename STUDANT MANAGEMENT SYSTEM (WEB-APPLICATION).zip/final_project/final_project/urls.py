from django.contrib import admin
from django.urls import path
from final_app.views import sign_in, sign_up, dashboard, ulogout, change_password, addstudent, adddept, viewdept, viewstudent, removedept, removestudent, adminlogin, adminpage, userlogin
from django.conf.urls.static import static
from django.conf import settings

urlpatterns = [
    path('admin/', admin.site.urls),
    path("",sign_in, name = "sign_in"),
    path("sign_up/", sign_up, name = "sign_up" ),
    path("dashboard/", dashboard, name = "dashboard"),
    path("ulogout/", ulogout, name = "ulogout"),
    path("change_password/", change_password, name = "change_password"),

    path("adminlogin/", adminlogin, name = "adminlogin"),
    path("adminpage/", adminpage, name = "adminpage"),
    path("userlogin/", userlogin, name = "userlogin"),

    path("addstudent/", addstudent, name = "addstudent"),
    path("adddept/", adddept, name = "adddept"),
    path("viewdept/", viewdept, name = "viewdept"),   
    path("viewstudent/", viewstudent, name = "viewstudent"),
   
    path("removedept/<int:id>", removedept, name = "removedept"),
    path("removestudent/<int:id>", removestudent, name = "removestudent"),

    
] + static(settings.MEDIA_URL, document_root = settings.MEDIA_ROOT)
